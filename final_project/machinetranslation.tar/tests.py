import translator

frenchText = translator.englishToFrench(None)
print(frenchText)

englishText = translator.frenchToEnglish(None)
print(englishText)